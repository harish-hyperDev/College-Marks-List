# CRUD


A React CRUD App using Tailwind CSS, Axios, React-Router-Dom and Json-Server. 


We've uesd the fake JSON-server for our fake APIs and use React Axios package to perform HTTP Requests in react.


We  follow the RESTful API convention (GET, POST, PUT, DELETE) and see how easily we do CREATE, READ, UPDATE and DELETE operations on our User Details.


We've learned so far about how to send data to server and get the response back from server.


We've seen how we can update our React state with the data received from the server and render our UI with that updated data.
